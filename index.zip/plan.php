<?php 

require_once "conn.php";

$sql = "SELECT * FROM plan WHERE id = $id";

?>